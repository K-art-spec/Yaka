from flask import Flask, jsonify, request

# Initialize Flask app
app = Flask(__name__)

# Basic route to check if the app is running
@app.route('/')
def hello_world():
    return 'Hello, World! Flask is running.'

# Example API route to test JSON response
@app.route('/api', methods=['GET'])
def api_test():
    return jsonify({"message": "This is a test API response"})

# Example of POST route handling data
@app.route('/api/data', methods=['POST'])
def api_post_data():
    data = request.get_json()
    if data:
        return jsonify({"status": "success", "data_received": data}), 200
    else:
        return jsonify({"status": "error", "message": "No data received"}), 400

# Error handling example
@app.errorhandler(404)
def page_not_found(error):
    return jsonify({"status": "error", "message": "Page not found"}), 404

# Error handling for internal server error
@app.errorhandler(500)
def internal_error(error):
    return jsonify({"status": "error", "message": "Internal server error"}), 500

# Main function to run the Flask app
if __name__ == "__main__":
    # Run Flask with debug mode enabled for better error logging
    app.run(debug=True)


