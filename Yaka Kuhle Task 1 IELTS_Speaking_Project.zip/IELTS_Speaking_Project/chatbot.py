import openai

openai.api_key = "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"

def get_ai_response(transcript):
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": f"Analyze this IELTS speaking response and give feedback: {transcript}"}]
    )
    return response["choices"][0]["message"]["content"]
