// app.js
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    const resultDiv = document.querySelector('#result');
    
    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent form submission (page reload)
        
        const formData = new FormData(form);
        
        // Show loading message
        resultDiv.innerHTML = "<p>Loading...</p>";

        fetch('/', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            resultDiv.innerHTML = data;
        })
        .catch(error => {
            resultDiv.innerHTML = "<p>Error submitting the form.</p>";
            console.error(error);
        });
    });
});
