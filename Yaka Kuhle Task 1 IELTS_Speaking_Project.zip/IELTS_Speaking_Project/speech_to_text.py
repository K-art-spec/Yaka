import requests

API_KEY = "77ca3304d1424d7fa32fbda76a0c2561"

def transcribe_audio(file_path):
    headers = {"authorization": API_KEY}
    
    with open(file_path, "rb") as audio_file:
        response = requests.post("https://api.assemblyai.com/v2/upload", headers=headers, files={"file": audio_file})
    
    audio_url = response.json()["upload_url"]

    transcript_response = requests.post("https://api.assemblyai.com/v2/transcript", headers=headers, json={"audio_url": audio_url})
    transcript_id = transcript_response.json()["id"]

    # Polling for result
    while True:
        transcript_result = requests.get(f"https://api.assemblyai.com/v2/transcript/{transcript_id}", headers=headers).json()
        if transcript_result["status"] == "completed":
            return transcript_result["text"]